 <?php


// Turn off error reporting
error_reporting(0);

// Report runtime errors
error_reporting(E_ERROR | E_WARNING | E_PARSE);

// Report all errors
error_reporting(E_ALL);

// Same as error_reporting(E_ALL);
ini_set("error_reporting", E_ALL);

// Report all errors except E_NOTICE
error_reporting(E_ALL & ~E_NOTICE);

include("db_connect.php");

$date1=$_POST['date2'];
$date= date("Y-m-d", strtotime($date1) );
$fee=$_POST['fee'];
$country=$_POST['country'];
$sum1=$_POST['sum'];
// For Remove $ symbol from sum
$sum = trim($sum1, '$');
$gst1=$_POST['gst'];
// For Remove $ symbol from Gst
$gst = trim($gst1, '$');

$sql = "INSERT INTO history (`date`, `fee`, `country`, `sum`, `gst`)
VALUES ('$date', '$fee', '$country', '$sum', '$gst' )";

if ($conn->query($sql) === TRUE) {


  //  echo "New record created successfully";

$output = ''; 
 $sql = "SELECT * FROM history ORDER By id desc LIMIT 5";
$result = mysqli_query($conn, $sql);
$i=1;
if (mysqli_num_rows($result) > 0) {

while($row = mysqli_fetch_assoc($result)) {
    $output .= '
    <tr>
    <td> '.$i.' </td>
      <td>'.$row['date'].'</td>
      <td>$'.$row['sum'].'</td>
      <td>$'.$row['gst'].'</td>
      
    </tr>
    '; 
    $i++;
}}
echo $output;



} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}




?>
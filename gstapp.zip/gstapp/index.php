<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>GST Application</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="css/font.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
   

<!-- table style    -->

  <style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 80%;
  border: 1px solid #000;
  }

th, td {
        text-align: left;
        padding: 8px;
        }
      tr:nth-child(even){background-color: #f2f2f2}
  </style>
</head>

<body>
   <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">GST Application</h2>

 <!-- Form starts-->
  <form method="POST" action=""  id="cform">
      <div class="input-group">
    <span class="label-input100">Date:</span>
    <input class="input--style-1" type="date" placeholder="dd/mm/yyyy" name="date2" onchange="test()" 
     id="date" required>
     </div>            
     <div class="row row-space">
       <div class="col-2">
       <div class="input-group">
       <span class="label-input100">Fee:</span>
       <input class="input--style-1" type="number" min="0" step="0.01" placeholder="" onkeyup="test()" name="fee" id="fee" required> 
        </div>
        </div>
               <div class="col-2">
                    <div class="input-group">
                        <div class="rs-select2 js-select-simple select--no-search">
                         <span class="label-input100">Country:</span>
                           <select id="country" name="country" onchange="test()">
                              <option disabled="disabled" selected="selected" ></option>
                              <option value="0">Please select</option>
                              <option value="India">India</option>
                              <option value="Singapore">Singapore</option>
                              <option value="Japan">Japan</option>
                              <option value="Bangladesh">Bangladesh</option>
                           </select>
                            <div class="select-dropdown"></div>
                          </div>
                      </div>
                </div>
      </div>

    <div class="row row-space">
      <div class="col-2">
      <div class="input-group">
      <span class="label-input100">Total Amount:</span>
      <input class="input--style-1" type="text" placeholder="" name="sum" id="sum"  required readonly>  
      </div>
      </div>           
        <div class="col-2">
        <div class="input-group">
          <span class="label-input100">GST</span>
          <input class="input--style-1" type="text" placeholder="" name="gst" id="gst"  required readonly> 
        </div>
        </div>
    </div>
             
        <div class="p-t-20" >
          <input  class="btn btn--radius " name="submit" type="submit" id="submit" value="Submit"  
        disabled="disabled">  
         </div>
                    
  </form>
   </div>

<!--   History Table   ( Diaplay Latest 5 history )       -->
<div  style="overflow-x:auto;" align="center">
    <h3 align="center">History</h3>
    <br>
  <table>
    <tr>
      <th>Sl No</th>
      <th>Date</th>
      <th>Total Amount</th>
      <th>Gst</th>
    </tr>

<!--  Display Data From database (from post.php page)   -->
    <tbody  id="created"></tbody>
  </table>
</div>
<br><br><br><br>
        </div>
        </div>
        </div>

    <script src="js/jquery-1.11.0.min.js"></script>
       <script src="js/jquery.min.js" type="text/javascript"></script>
       <script src="js/jquery-1.9.1.js"></script>
    <script src="js/jquery.js"></script>

<!-- For enable submit button   -->
<script>
  test = function() {
    if($("#date").val() && $("#fee").val() && $("#country").val() ){
         $("#submit").removeAttr("disabled");
         $('#submit').css({background:'#82CFFD'});
    }
}
</script>


<!--   For Disable submit button / Form Submission/ History Table / Form clear  -->
    <script>
      $(function () {
        $('form').on('submit', function (e) {

           //   For Disable submit button
           $(this).find(':input[type=submit]').prop('disabled', true);
           $('#submit').css({background:'#A9A9A9'});
          e.preventDefault();
          $.ajax({
            type: 'post',
            url: 'post.php',
            data: $('form').serialize(),
            success: function(data) { // on success..
            // History Table
            $('#created').html(data);
                
            //Form clear
            document.getElementById("cform").reset();
            $('#cform')[0].reset();                       
            $('#country').val('').trigger("change");
            alert("GST Submitted successfully!")
            }
          });
        });
      });
    </script>
    
<!--  For Gst & Total Amount Calculation  -->
   <script type='text/javascript' src='js/jquery.1.7.1.js'></script>
<script>
$(function() {
    $("#fee, #country").on("keydown keyup blur change", sum);
    function sum() {
 if($('#country').val() =='Singapore')
{
// Find Sum
 $("#sum").val((Number($("#fee").val()) * (0.07)  +  Number($("#fee").val())).toFixed(2) );
// Add $ symbol
 $("#sum").val('$'+$("#sum").val());
     // Find GST
    $("#gst").val((Number($("#fee").val()) * (0.07) ).toFixed(2) ); 
    //Add $ symbol
    $("#gst").val('$'+$("#gst").val());
} 
else{
  $("#sum").val(Number($("#fee").val()) );
    $("#gst").val(Number($("#fee").val()) * 0);  
}
  }
});

</script>
    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>
    <!-- Main JS-->
    <script src="js/global.js"></script>
</body>
</html>
<!-- end document-->